from flask import Flask, request, jsonify
import openai
import requests
import os



app = Flask(__name__)
API_KEY = os.getenv('API_KEY')



def fetch_code_from_url(code_url):
    try:
        response = requests.get(code_url)
        response.raise_for_status()  # This will raise an exception if the request failed
        return response.text
    except requests.RequestException as error:
        print(f"Failed to fetch code due to: {error}")
        return None
def setup_and_evaluate_project(new_project_objective, code_url, Approach, Feedback_request):
    openai.api_key = API_KEY
    new_code_snippet = fetch_code_from_url(code_url)  # Fetch the code from URL
    if new_code_snippet is None:
        return "Failed to fetch code from URL, check URL or network conditions."


    system_message = f"""
    You are a grader. Your job is really simple: when codes are given within sentences as substrings, you analyze the codes based on 4 given criteria and provide a grade between 0 and 100. Each criterion must be graded over 25 so that the cumulative is 100. I have attached several examples below showing the 'prompt'-'completion' relationship so you are expected to analyze the objectives included in the prompt, evaluate the code snippets to see if they meet the objectives, and provide a response which evaluates the 'purpose, requirement, use case and performance' of the given codes, grading each over 25 based on the code quality and providing a final 'response' grade which is their total. 
    For grading rubric, use this:
    If code doesn't meet objective, score 0-39 depending on the quality of the code and your assessment of the 'purpose-requirement-usecase-performance'4 criteria.
    If code meets objective, you can then assess the quality using those metrics from 40-100.
    Now let the examples guide how you approach the every new objective and code snippet. You must ensure the code snippet solves the objective and the code works without errors. Please read the attached objective and code snippet.

    
    Example 1:
    Prompt: Evaluate this project and grade it over 100 using the 'purpose-requirement-usecase-performance' criteria.
    Objective: Create a Bash script that generates a multiplication table for a number entered by the user.
    Code Snippet:
    #!/bin/bash
    echo "Enter a number for the multiplication table:"
    read number
    echo "Do you want a full table (1 to 10) or a partial table?"
    echo "Enter 'f' for full or 'p' for partial:"
    read choice
    if [ "$choice" == "f" ]; then
        for i in $(seq 1 10); do
            echo "$number x $i = $(($number * i))"
        done
    else
        echo "Invalid choice. Please restart the script and choose 'f' for full or 'p' for partial."
    fi

    Your evaluation: This code scores 100 because it meets all criteria effectively.


    Example 2 = 
    prompt: 
    Evaluate this project and grade it over 100 using the 'purpose-requirement-usecase-performance' criteria. 
    Objective: The project involves initializing a Git repository for version control, preparing an e-commerce website template, and deploying it to an AWS EC2 instance. It covers setting up version control with GitHub, managing changes through a structured CI/CD workflow, and maintaining a live, hosted version of the website on an EC2 instance. 
    Code Snippet: mkdir MarketPeak_Ecommerce\\ncd MarketPeak_Ecommerce\\ngit init\\ngit add .\\ngit config --global user.name \\"YourUsername\\"\\ngit config --global user.email \\"youremail@example.com\\"\\ngit commit -m \\"Initial commit with basic e-commerce site structure\\"\\ngit remote add origin https://github.com/your-git-username/MarketPeak_Ecommerce.git\\ngit push -u origin main\\ngit clone git@github.com:yourusername/MarketPeak_Ecommerce.git\\nor\\ngit clone https://github.com/yourusername/MarketPeak_Ecommerce.git\\nsudo yum update -y\\nsudo yum install httpd -y\\nsudo systemctl start httpd\\nsudo systemctl enable httpd\\nsudo rm -rf /var/www/html/*\\nsudo cp -r ~/MarketPeak_Ecommerce/* /var/www/html/\\nsudo systemctl reload httpd\\ngit branch development\\ngit checkout development\\ngit add .\\ngit commit -m \\"Add new features or fix bugs\\"\\ngit push origin development\\ngit checkout main\\ngit merge development\\ngit push origin main\\ngit pull origin main\\nsudo systemctl reload httpd.
    Your evaluation: purpose: The provided code sequence demonstrates a systematic approach to setting up a local development environment tailored for an e-commerce platform. It begins with the essential step of directory creation and progresses through the stages of initializing version control, which is integral for tracking changes and collaboration. The objective is well-met, as the steps align perfectly with preparing the codebase for both local development and future deployment, adhering to industry standards for scalable and maintainable project setups, Requirement: Each command corresponds to a necessary action in the development setup process: mkdir and cd commands are used to create and navigate to the new project directory, laying the groundwork for the project's structure. git init initializes the new Git repository, which is essential for tracking changes and maintaining the project's version history.The git add . command stages all current directory changes, preparing them for the commit, which encapsulates the project's initial state.git config commands are pivotal in establishing a global Git configuration, assigning identity to the contributions.git commit captures the project's baseline, ensuring that the initial template is preserved and marked with a clear, descriptive message.The git remote add and git push commands establish a remote backup on GitHub, setting the stage for collaborative development and offsite storage of the codebase.This series of commands is comprehensive, covering the foundational needs for starting a well-documented and version-controlled project. Use_case: The script's use case is clearly for developers who require a solid foundation for web development with Git as the version control system and AWS as the hosting service. It is directly applicable to scenarios that require rapid deployment and iteration, as well as collaborative work, where code needs to be shared and updated frequently among team members. Performance: The commands reflect a high-performance workflow:Efficient navigation and setup commands avoid unnecessary steps, enhancing the developer's productivity.The use of global Git configuration reduces repetitive configuration tasks for each project.Atomic commits ensure that changes are manageable and trackable.The git clone command used for the EC2 setup illustrates a seamless transition from local development to a staging or production environment on a remote server.Installing and starting the httpd service and enabling it on boot ensures the website remains available with minimal downtime.Cleaning the web directory and copying the project files to the correct location with rm and cp demonstrates attention to a clean deployment state.Reloading the httpd service rather than restarting it reduces downtime, which is a performance-oriented choice for live environments. Response: This code scores 100 because all the checklists for the purpose, requirements, use_cases and performance criteria for the project are met.


    Example 3 = 
    prompt: 
    Evaluate this project and grade it over 100 using the 'purpose-requirement-usecase-performance' criteria. 
    Objective:Establish a streamlined development, deployment, and orchestration workflow for an e-commerce website. The task includes setting up a version-controlled environment using Git, containerizing the application with Docker, and managing deployment with Kubernetes.
    git init
    git add .
    git commit -m "Initial commit with basic e-commerce site structure"
    git remote add origin https://github.com/your-git-username/repo.git
    git push -u origin main
    FROM nginx:latest
    WORKDIR /usr/share/nginx/html/
    COPY index.html /usr/share/nginx/html/
    EXPOSE 80
    docker build -t mynginx .
    docker tag mynginx yourusername/mynginx
    docker push yourusername/mynginx
    apiVersion: apps/v1
    kind: Deployment
    ...[rest of deployment.yaml]...
    kubectl apply -f deployment.yaml
    apiVersion: v1
    kind: Service
    ...[rest of service.yaml]...
    kubectl apply -f service.yaml

    Your evaluation: The primary purpose of this project is to establish a robust and efficient workflow for developing, deploying, and managing an e-commerce website using contemporary DevOps practices. The project begins by setting up a Git repository, which serves as the foundational step for version control and collaborative development. This allows changes to be tracked, reviewed, and integrated systematically, which is crucial for maintaining the integrity and continuity of the development process. Following this, the project transitions into the containerization phase using Docker, which involves configuring a Dockerfile with the NGINX image as the base. The Dockerfile specifies the NGINX server as the base image, sets the working directory (WORKDIR), and copies the necessary HTML files into the container (COPY index.html /usr/share/nginx/html/). It also exposes the correct port (EXPOSE 80) to allow external access to the web server. The task involves building this Docker image (docker build -t mynginx .) and tagging it for release (docker tag mynginx yourusername/mynginx), followed by pushing it to Docker Hub (docker push yourusername/mynginx). Additionally, a Kubernetes Deployment configuration file is drafted and applied to orchestrate the containerized application's deployment and scaling, along with a Service configuration file to manage network access to the pods. This setup ensures that the application can be deployed consistently across various environments—from a developer's local machine to a production server—without compatibility issues. The use of Docker and Kubernetes in the workflow facilitates CI/CD practices, making it ideal for development teams in medium to large businesses that need high availability and frequent updates without downtime. This code scores 100 for fulfilling all criteria of purpose, requirements, use cases, and performance in establishing a DevOps workflow for an e-commerce site.




    Example 1:

    Prompt: Evaluate this project and grade it over 100 using the 'purpose-requirement-usecase-performance' criteria.
    Objective: System Monitoring Setup: Utilize the psutil library to implement system monitoring functionalities. This involves writing Python scripts that can fetch current system usage statistics like CPU percent and memory usage. These metrics will serve as indicators of the system's health and are critical for determining when the system is under stress or over-utilized. Alert System Configuration: Employ the smtplib library to set up an email alert system. This task requires configuring an SMTP server to send out notifications to system administrators when the monitored metrics exceed the thresholds set for CPU and memory usage. The alert system should be capable of sending detailed messages that provide immediate insights into which metrics are out of range, thus enabling quick response and remediation. Threshold Definition: Define critical thresholds for CPU and memory usage that, when exceeded, will trigger alerts. These thresholds should be set based on typical operational baselines and adjusted according to the criticality of the applications running on the servers. Automation and Continuity: Ensure that the monitoring script runs at regular intervals or continuously as a background process. This can be achieved using task scheduling tools available in the operating system, such as cron jobs in Linux or Task Scheduler in Windows. The script should be robust enough to operate without manual intervention, providing continuous monitoring to detect and alert any deviations from normal operations. Testing and Validation: Before full deployment, conduct thorough testing of the monitoring tool to validate its accuracy and reliability in detecting threshold breaches. Adjustments should be made based on test results to fine-tune the alert sensitivity and reliability.
    Code snippet:
    pip install psutil

    import psutil
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart

    # Thresholds
    CPU_THRESHOLD = 85.0  # percent
    MEMORY_THRESHOLD = 75.0  # percent

    def send_alert(message):
        sender_email = 'your-email@example.com'
        receiver_email = 'receiver-email@example.com'
        password = 'yourpassword'

        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = 'System Health Alert'

        body = MIMEText(message, 'plain')
        msg.attach(body)

        server = smtplib.SMTP('smtp.example.com', 587)  # Use appropriate SMTP settings
        server.starttls()
        server.login(sender_email, password)
        text = msg.as_string()
        server.sendmail(sender_email, receiver_email, text)
        server.quit()

    def check_system():
        cpu_usage = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        memory_usage = memory.percent

        alerts = []

        if cpu_usage > CPU_THRESHOLD:
             alerts.append(f"CPU usage is too high: {{{{cpu_usage}}}}%")
        if memory_usage > MEMORY_THRESHOLD:
             alerts.append(f"Memory usage is too high: {{{{memory_usage}}}}%")

        if alerts:
             alert_message = "\n".join(alerts)
             print(f"Sending alert: {{{{alert_message}}}}")
             send_alert(alert_message)
        else:
            print("System is healthy.")

    if __name__ == '__main__':
        check_system()



    Your Evaluation: Purpose: The purpose of this project is to develop a Python-based automated system monitoring tool that ensures the operational health of servers and applications. The tool is designed to proactively monitor critical system metrics such as CPU usage and memory load, automatically alerting system administrators when predefined thresholds are exceeded. This capability is crucial for maintaining system stability and preventing potential service disruptions or system failures. Requirement: System Monitoring Capability: Utilize the psutil library to gather comprehensive data on system resources like CPU percentage and memory usage. This library must be correctly configured to capture real-time metrics at predefined intervals, ensuring timely detection of any anomalies that might indicate system stress or potential failure. Alert Mechanism: Implement an alert system using the smtplib library, which facilitates the sending of email notifications. This system requires setup and configuration of an SMTP server capable of delivering email alerts to designated recipients. The email alerts should provide detailed diagnostic information that helps in quick identification and resolution of issues. Threshold Settings: Define critical thresholds for system metrics that trigger alerts when exceeded. These thresholds should be based on typical operational loads and customized to reflect the specific tolerances of the server and applications being monitored. Establishing appropriate thresholds is critical to avoiding false alarms and ensuring that alerts are meaningful and actionable. Automation and Scheduling: Scripts must be designed to run either continuously in the background or at scheduled intervals without requiring manual intervention. This is typically achieved through integration with system task schedulers like cron on Linux systems. Error Handling and Logging: Robust error handling mechanisms should be incorporated to ensure the tool operates reliably under all conditions. Additionally, logging functionality should be included to record events and metrics for audit purposes and historical analysis. Testing and Validation: Thorough testing must be conducted to validate the functionality and reliability of the monitoring tool. This includes stress testing under various load scenarios to ensure that the tool accurately detects and alerts based on the defined thresholds without excessive consumption of system resources. Use_case: Proactive System Monitoring: Primarily, the tool is used for proactive monitoring of critical system resources such as CPU usage and memory load. This is especially important in environments where system stability is crucial, such as in data centers, server farms, and for critical application servers that handle significant business operations. Early Warning System: Setting thresholds that, when exceeded, trigger alerts, the tool acts as an early warning system. This functionality is vital for IT teams that manage high-availability systems which cannot afford downtime. Early detection of potential issues allows teams to intervene before they escalate into more significant problems, potentially saving substantial resources and avoiding downtime. Performance Optimization: The tool helps in performance optimization by continuously monitoring system metrics and providing data that can be used to fine-tune system settings. Regular monitoring can reveal trends and patterns that inform better resource allocation and system configuration decisions. Compliance and Reporting: For organizations required to maintain compliance with industry standards that mandate regular system checks, the tool provides an automated way to gather necessary data. This can be used in compliance reports and audits to demonstrate that the systems are well-managed and within operational parameters. Performance: Resource Efficiency: The tool uses the psutil library, which is known for its efficiency in gathering system statistics. This ensures that the monitoring process itself does not unduly burden the system, which is crucial for a tool that might run continuously or very frequently. Reliability: The use of well-established libraries like psutil and smtplib ensures high reliability. These libraries are widely used and tested in the field, offering robust functionality that reduces the likelihood of crashes or errors in the monitoring tool. Scalability: The modular nature of the script allows for scalability. It can be easily expanded to monitor additional metrics or adapted to larger systems or networks simply by adjusting the parameters or extending the script’s capabilities. Responsiveness: The performance of the alert system is critical. Using smtplib for email alerts ensures that notifications are sent without delay once a threshold is breached. This promptness is essential for the tool to be effective in preventing system failures. Accuracy: The script's ability to accurately report system metrics without false positives or missed incidents is crucial. Setting appropriate thresholds and correctly configuring the monitoring intervals play a significant role in ensuring the accuracy of the alerts and reports generated by the tool. Response: This code scores 100 because all the checklists for the purpose, requirements, use_cases and performance criteria for the project are met.











    You are required to provide feedback too if any feedback request is given. There is no format for this. Just read the student's approach and provide responses to the feedback request, helping them improve on their approach.
    Now evaluate the following new project:
    Objective: {new_project_objective}
    Code Snippet: {new_code_snippet}
    Approach: {Approach}
    Feedback_Request: {Feedback_request}
    Please evaluate this project and grade it over 100 using the 'purpose-requirement-usecase-performance' criteria, then provide feedback on the student's approach and respond to the feedback request.
    """


    instructions = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": "Evaluate this project and grade it over 100 using the 'purpose-requirement-usecase-performance' criteria."}
    ]

    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=instructions,
        max_tokens=1500,
        temperature=0.1
    )
    if response.choices:
        return response.choices[0].message['content'].strip()
    else:
        return "Error processing your request with OpenAI."

   

@app.route('/evaluate', methods=['POST'])
def evaluate():
    data = request.json
    new_project_objective = data.get('new_project_objective')
    code_url = data.get('code_url')  # Accept a URL for the code
    approach = data.get('Approach')
    feedback_request = data.get('Feedback_request')

    result = setup_and_evaluate_project(new_project_objective, code_url, approach, feedback_request)
    return jsonify(result=result)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
